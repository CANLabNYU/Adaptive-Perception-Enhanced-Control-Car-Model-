from time import sleep

from .context import control
from control.controller import Controller


def test_controller():
    pass


if __name__ == '__main__':
    test_controller()
