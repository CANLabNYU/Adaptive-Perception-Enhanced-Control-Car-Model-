class Detector(object):
    pass
